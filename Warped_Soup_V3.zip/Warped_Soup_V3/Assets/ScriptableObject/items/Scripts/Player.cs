using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
public class Player : MonoBehaviour
{
    public InventoryObject inventory;
    public Text pickUpText;
    //private bool isPickable = false;
    private List<GameObject> itemList = new List<GameObject>();
    // Start is called before the first frame update

    void Start()
    {
        inventory.Container.Clear();
        pickUpText.gameObject.SetActive(false);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            Debug.Log(itemList);
            foreach (GameObject obj in itemList)
            {
                var item = obj.GetComponent<Item>();
                if (item)
                {
                    inventory.AddItem(item.item, 1);
                    Destroy(obj.gameObject);
                }
            }
            itemList.Clear();
            pickUpText.gameObject.SetActive(false);
        }
    }

    public void OnTriggerStay(Collider collision)
    {
        pickUpText.gameObject.SetActive(true);
    }

    public void OnTriggerExit(Collider collision)
    {
        pickUpText.gameObject.SetActive(false);
        itemList.Remove(collision.gameObject);
    }

    public void OnTriggerEnter(Collider other)
    {
        itemList.Add(other.gameObject);
    }

    /*public void OnTriggerEnter(Collider other)
    {
        var item = other.GetComponent<Item>();
        if (item)
        {
            inventory.AddItem(item.item, 1);
            Destroy(other.gameObject);
        }
    }*/

    private void OnApplicationQuit()
    {
        inventory.Container.Clear();
    }
}
